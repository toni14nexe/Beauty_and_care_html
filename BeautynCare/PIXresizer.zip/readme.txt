


        PIXresizer 2.0.8
        Copyright (C) 1997-2014 David De Groot
        Updates and other freeware: http://bluefive.pair.com/
        Frequently Asked Questions: http://bluefive.pair.com/faq.htm


        -------------------------------------------------------------------------
        Intro
        -------------------------------------------------------------------------

        PIXresizer is a tool for quickly generating screen-friendly versions of
        your images with dramatically reduced file sizes. It is a photo resizing
        program that enables you to quickly resize one file or a selection of
        image files for use on the web and in e-mail. The reduced files are saved
        in a different directory, so your original pictures are not changed.

        The program offers several different resizing methods to choose from and
        can automatically recognize image sizes to calculate the best fit.
        PIXresizer includes a built-in image viewer and you can also convert
        between graphics formats: it opens and saves in .bmp, .gif, .jpg, .png,
        and .tif formats. A great companion for webmasters and digital
        photographers.


        -------------------------------------------------------------------------
        Requirements
        -------------------------------------------------------------------------
        A file you _may_ need is the VBruntime.
        You can read about this file and download it at the BlueFive homepage at
        http://bluefive.pair.com/vbrun.htm

        Windows 98 and Windows NT4 users need to have Internet Explorer 5.0 or
        higher installed.

        Since v2.0.0 PIXresizer will not run on Windows 95 anymore.


        -------------------------------------------------------------------------
        Installation
        -------------------------------------------------------------------------
        Automatic installation (double-click the Setup.exe file).

        Note:
        Installation requires an Administrator's account.

        To uninstall:
        click the 'Uninstall PIXresizer' icon in the Start menu, or go to
        Control Panel/Software/PIXresizer and click "Remove".


        -------------------------------------------------------------------------
        Usage
        -------------------------------------------------------------------------
        Using it is very easy.

        ***** TO WORK WITH ONE FILE *********************************************

        Click the 'Work with one file' tab and follow steps 1 to 4:

        1. Load picture
        2. Select new size
        3. Select file format
        4. Save picture

        You can use the 'Apply recommended' button to set the options for you:
        it will force a 600 pixels size (larger dimension) and the .jpg format.
        (600 pixels is the recommended size for sending images via e-mail, and
        posting on the web).

        /Note/
        There's more in the PIXresizer Help file, which is available at anytime
        in the program by pressing the F1-key, or by pressing the Help button.


        ***** TO WORK WITH MULTIPLE FILES AT ONCE *******************************

        Click the 'Work with multiple files' tab and follow steps 1 to 4:

        1. Select source and destination
        2. Select new size
        3. Select file format
        4. Save pictures

        You can use the 'Apply recommended' button to set the options for you:
        it will force a 600 pixels size (larger dimension) and the .jpg format.
        (600 pixels is the recommended size for sending images via e-mail, and
        posting on the web).

        /Note/
        There's more in the PIXresizer Help file, which is available at anytime
        in the program by pressing the F1-key, or by pressing the Help button.

        [CANCEL]

        If you need to cancel the process, click the 'Click here to Cancel'
        label, just beneath the progress bar.

        [SPEED]

        The time PIXresizer needs to complete the process depends on the number
        of images being processed, and their original sizes. Having the
        'Show Preview' on slows things down.

        [SKIPPED FILES]

        PIXresizer won't process files when they:
          - are in use
          - are not real images
          - are of the same size as your size setting
        It will however produce a list of errored files for your examination
        afterward.

        * TIP *
        To produce THUMBNAILS from your pictures move the slider until the
        pixel-box shows '96', or double-click the pixel-box, enter 96 and hit OK.
        96 is the default size for thumbnails (larger dimension).

        * TIP *
        Source and Destination entries (for a batch resize) are editable. 
        Just press SHIFT and click into the textbox simultaneously and you can 
        start typing, or pasting.

        * TIP *
        If you like to replace the startup image on the single tab window, just
        replace the PIXresizer.jpg file with your image (not a +1MB file please!)
        in the PIXresizer program folder.


        -------------------------------------------------------------------------
        Thanks
        -------------------------------------------------------------------------
        Special thanks to:
        Clark Vansteensel for his contributions, time, effort and support.
        Brad Martinez for his superb CCRP BrowseDialog Server.
        Domenico Statuto for his superb CCRP FileDialogs Control.
        More info: http://ccrp.mvps.org/


        -------------------------------------------------------------------------
        Distribution
        -------------------------------------------------------------------------
        This program is freeware. There is no charge for using it and it may be
        distributed freely so long as the files are kept together and unaltered.
        You may neither sell nor profit from distribution of this software in any
        way. Distribution on CD/DVD, Shareware-disks, in shops or through
        networks are allowed as long as

        a) no money (for the program itself) is taken
        b) each file of the original ZIP-file is included and
        c) you informed me about it.

        Distribution via web sites is granted as long as

        a) the original ZIP-file is used and
        b) a working link to http://bluefive.pair.com/ is provided.


        -------------------------------------------------------------------------
        Disclaimer
        -------------------------------------------------------------------------
        This software is provided as is and without warranty.
        The author assumes no liability for damages, either direct or
        consequential, which may result from the use of this product.



        Thanks for using PIXresizer!
        David De Groot
        ddg AT telenet.be

        �������������������������������������������������������������������������
        Keep your copy up-to-date! Please check regularly for updates at:
        http://bluefive.pair.com/

        �������������������������������������������������������������������������




